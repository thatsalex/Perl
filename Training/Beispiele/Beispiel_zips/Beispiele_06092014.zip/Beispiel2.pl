#!/usr/bin/perl
print "Dein Name: ";
$name = <stdin>;
chomp($name);   #entfernt letzten \n
print "Hallo $name!";
#print "Hallo $name"x3;
#$zahl = -10.8%3.2;
#print "$zahl";
$z ="111Hallo"*3;
print $z;
