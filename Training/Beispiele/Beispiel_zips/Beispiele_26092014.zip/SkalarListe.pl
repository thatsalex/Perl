#!/usr/bin/perl
use strict;
my $ding = "irgendetwas";
print "$ding\n";
my ( $name, $tel)=("irgendetwas","irgendwo");
print "$name $tel\n";
