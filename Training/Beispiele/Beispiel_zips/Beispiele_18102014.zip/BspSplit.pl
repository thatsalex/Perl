#!/usr/bin/perl
use strict;
$_ = <STDIN>;
my @arr = split /:\./;

print "@arr\n";